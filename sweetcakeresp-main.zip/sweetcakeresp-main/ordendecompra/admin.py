from django.contrib import admin
from .models import OrdenDC
# Register your models here.
admin.site.register(OrdenDC)