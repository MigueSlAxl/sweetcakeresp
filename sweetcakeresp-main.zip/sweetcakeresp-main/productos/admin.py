from django.contrib import admin
from .models import Productos,Categoria
# Register your models here.
admin.site.register(Productos)
admin.site.register(Categoria)
